package com.example.moviedatabasebase.util


const val BASE_URL = "https://api.themoviedb.org/3/"
const val API_KEY = "38a73d59546aa378980a88b645f487fc"
const val IMAGE_BASE_PATH = "https://image.tmdb.org/t/p/w500"

